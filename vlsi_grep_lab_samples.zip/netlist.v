module alu (a, b, y, clk);
  input a, b, clk;
  output y;

  wire n1, n2;

  NAND2_X1 U1 ( .A(a), .B(b), .ZN(n1) );
  INV_X1   U2 ( .A(n1), .ZN(n2) );
  DFF_X2   U3 ( .D(n2), .CLK(clk), .Q(y) );

endmodule
