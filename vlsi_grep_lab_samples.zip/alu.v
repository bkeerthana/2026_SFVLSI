module alu #(parameter W=8) (input  logic clk,
                                 input  logic [W-1:0] a,b,
                                 input  logic [1:0] op,
                                 output logic [W-1:0] y);
  logic [W-1:0] add_r, and_r, xor_r;

  // Combinational blocks
  always @* begin
    add_r = a + b;
    and_r = a & b;
    xor_r = a ^ b;
  end

  // Sequential block
  always @(posedge clk) begin
    case(op)
      2'b00: y <= add_r;
      2'b01: y <= and_r;
      2'b10: y <= xor_r;
      default: y <= {W{1'b0}};
    endcase
  end
endmodule
