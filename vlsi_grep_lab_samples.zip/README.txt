VLSI grep/regex Lab Sample Files
=================================

Files included:
- sim.log               : sample simulation log with INFO/WARNING/ERROR
- timing_report.rpt     : small timing report containing setup/hold violations
- netlist.v             : gate-level style snippet with INV/NAND2/DFF cells
- alu.v                 : RTL example with always blocks for regex tasks
- stdcells.lib          : minimal standard cell library text
- constraints.sdc       : SDC constraints with comments (for filtering)
- cells.txt             : list of cells to search in netlist.v
- sim_results.log       : lines with numbers and trailing 'clk' for regex
- truth_table.txt       : contains the word 'nand' for word-boundary tests

Suggested exercises are aligned with these files (grep -n/-c/-i/-q, -A/-B/-C,
-e/-E/-f/-h/-l/-s, egrep, and regular expressions).
