# Clock definition
create_clock -name clk -period 10 [get_ports clk]

# Input delay
set_input_delay -max 3 -clock clk [get_ports a]

# Output delay
set_output_delay -max 2 -clock clk [get_ports y]

# False path
set_false_path -from [get_ports reset]
